import json
import argparse


simulator_parameters = {
    "simulation": "debug_config",
    "evaluation": "S1",
    "city": "nyc",
    "horizon": "horizon_1_2k",
    "fleet": "fleet_20",
    "infrastructure": "S05_1_4",
}

extra_parameters = {
    "agent": "nearest",
}

# Mapping of parameter names to their subfolder in config directory
config_folder_mapping = {
    "simulation": "simulation",
    "evaluation": "evaluation", 
    "city": "city",
    "horizon": "horizon",
    "fleet": "fleet",
    "infrastructure": "infrastructure",
    "agent": "agent",
}


def get_parser(**kwargs):
    parser = argparse.ArgumentParser()
    merged_args = {**simulator_parameters, **extra_parameters, **kwargs}
    for key, value in merged_args.items():
        if type(value) == int:
            arg_type = int
        else:
            arg_type = str
        parser.add_argument(f"--{key}", type=arg_type, default=value)
    return parser


def load_config(args, source_dir="./data/config"):
    instance_config = {}
    extra_config = {}

    # process the main config files
    for key, value in vars(args).items():
        # at the moment, we only want to process the main config files
        if len(key.split("_")) != 1:
            continue
        
        # Skip if this parameter doesn't have a folder mapping
        if key not in config_folder_mapping:
            continue
            
        # load the config file from the appropriate subfolder
        subfolder = config_folder_mapping[key]
        config_loc = f"{source_dir}/{subfolder}/{value}.json"
        with open(config_loc, "r") as config_file:
            # place the config in the appropriate dictionary
            if key in simulator_parameters:
                instance_config[key] = json.load(config_file)
            else:
                extra_config[key] = json.load(config_file)

    # process the overrides and additional parameters
    for key, value in vars(args).items():
        split_key = key.split("_")
        if len(split_key) != 2:
            continue
        if split_key[0] in instance_config:
            instance_config[split_key[0]][split_key[1]] = value
        elif split_key[0] in extra_config:
            extra_config[split_key[0]][split_key[1]] = value
        else:
            raise (ValueError(f"Unknown parameter key: {split_key[0]}"))

    return instance_config, extra_config
