from .agent import Agent
from .nearest import NearestAgent
from .random_agent import RandomAgent

__all__ = [
    "Agent",
    "AgentT4",
    "NearestAgent",
    "PeriodicPPOAgent",
    "RandomAgent",
]


def __getattr__(name):
    """Load optional agents only when they are explicitly requested."""
    if name == "PeriodicPPOAgent":
        from .periodic_ppo import PeriodicPPOAgent

        return PeriodicPPOAgent
    if name == "AgentT4":
        try:
            from .agent_t4 import AgentT4
        except ImportError as exc:
            raise ImportError(
                "AgentT4 requires the optional optimization dependencies. "
                "Install OpenHail with 'pip install openhail[optimization]'."
            ) from exc
        return AgentT4
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
