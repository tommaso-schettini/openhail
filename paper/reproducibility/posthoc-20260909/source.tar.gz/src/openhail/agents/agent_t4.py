import gurobipy as gb
import numpy as np
import logging

from ..utils import geometry
from ..utils.infrastructure_utilities import ChargingInfrastructure
from . import Agent
from ..core.constants import JOB_GO_CHARGE, ORIG, JOB_REPO, TIME, TYPE, Q
from ..utils import state_utilities as state_utilities


class AgentT4(Agent):
    def __init__(
        self,
        instance_config: dict,
        soc_threshold: float = 1.0,
        do_service: bool = True,
        do_rebal: bool = True,
        rebal_status_limit: int = 5,
        request_factor: int = 4,
        request_weight: float = 10.0,
        **kwargs,
    ):
        Agent.__init__(self, instance_config, **kwargs)

        self.do_service = do_service
        self.do_rebal = do_rebal
        self.rebal_status_limit = rebal_status_limit

        self.rebal_step = 150.0
        self.next_rebal = self.rebal_step

        # -> optimization options
        self.opt_timelimit = 20
        # -> parameter generation
        self.request_window = 1200
        self.request_factor = request_factor
        self.doy = 0
        # -> parameters
        self.request_weight = request_weight
        self.mid_Q_thr = 0.5
        self.low_Q_thr = 0.25
        self.recharge_weight = 5
        self.urgent_recharge_weight = 50
        # -> deprecated
        self.q_thresh = soc_threshold * self.instance.ev_max_Q
        return

    def set_doy(self, doy):
        self.doy = doy

        requests = self.instance.generate_requests_for_T(doy, 1234, num_requests=1400 * self.request_factor)
        self.request_orig = np.stack(requests[ORIG].values)
        self.request_time = requests[TIME].values

        self.next_rebal = self.instance.start_time + self.rebal_step

    def choose_action(self, state):
        V = state["V"]
        request = state["request"]
        time = state["time"]

        rnr_action = np.zeros(shape=(self.instance.num_evs,), dtype=np.int32)

        serve_action = state_utilities.compute_nearest_assignment(self.instance, request, V)
        V = state_utilities.update_state(self.instance, V, request, serve_action)
        logging.debug("time = {}, nearest = {}".format(time, serve_action))

        rnr_mask, rnr_dist = state_utilities.compute_rnr_mask(self.instance, V)
        idle_evs = V[TIME] <= time

        rebal_assignments = {}
        if time >= self.next_rebal:
            self.next_rebal += self.rebal_step
            rebal_assignments = self.choose_rnr(V, time, idle_evs, rnr_dist, rnr_mask)

        # Note which vehicles can reposition.
        # These vehicles 1) have to be eligible (have a feasible repositioning action), and 2) have to have insufficient charge
        insufficient_charge = (np.any(rnr_mask[:, 1:], axis=1)) & (V[Q] <= self.q_thresh)
        # -> compile repositioning
        for v in range(self.instance.num_evs):
            if v in rebal_assignments:
                rnr_action[v] = 2 * (rebal_assignments[v] + 1)

            elif V[TYPE][v] not in [JOB_REPO, JOB_GO_CHARGE] and (not rnr_mask[v, 0] or insufficient_charge[v]):
                # Assign EV to reposition to nearest CS
                recharge_loc = np.argmin(rnr_dist[v]) + 1
                rnr_action[v] = 2 * recharge_loc

        planned_epoch = np.asarray(self.next_rebal, dtype=np.float64)
        return serve_action, rnr_action, planned_epoch

    def choose_rnr(self, V, time, idle_evs, rnr_dist, mask_rnr):

        if not np.any(idle_evs):
            return {}
        request_indices = (self.request_time > (time % 86400)) & (
            self.request_time <= (time % 86400) + self.request_window
        )
        if not np.any(request_indices):
            return {}

        request_coords = self.request_orig[request_indices]
        cs_idxs = range(self.instance.D_repo)

        mid_Q_evs = V[Q] < self.mid_Q_thr * self.instance.ev_max_Q
        low_Q_evs = V[Q] < self.low_Q_thr * self.instance.ev_max_Q
        # -> compute the sampled demand
        counts = self._compute_request_count(cs_idxs, request_coords)
        # -> indexes
        idle_ev_idxs = idle_evs.nonzero()[0]
        mid_Q_idxs = (idle_evs & mid_Q_evs).nonzero()[0]
        low_Q_idxs = (idle_evs & low_Q_evs).nonzero()[0]
        dist_to_charger = rnr_dist[idle_ev_idxs, :]
        # -> model
        m = gb.Model()
        m.setAttr(gb.GRB.Attr.ModelSense, gb.GRB.MINIMIZE)
        # assignments
        x = m.addVars(
            [(v, c) for v in idle_ev_idxs for c in cs_idxs],
            lb=0,
            ub=1,
            vtype=gb.GRB.BINARY,
            name="x",
            obj=dist_to_charger.flatten() / self.instance.gdf_meters_per_unit,
        )
        # captured demand
        y = m.addVars(
            [(c) for c in cs_idxs],
            lb=0,
            vtype=gb.GRB.CONTINUOUS,
            name="y",
            obj=-self.request_weight,
        )
        # recharge
        z_mid = m.addVars(
            [(c) for c in cs_idxs],
            lb=0,
            vtype=gb.GRB.CONTINUOUS,
            name="z",
            obj=-self.recharge_weight,
        )
        z_low = m.addVars(
            [(c) for c in cs_idxs],
            lb=0,
            vtype=gb.GRB.CONTINUOUS,
            name="z",
            obj=-self.urgent_recharge_weight,
        )
        # For each request, it can be matched to at most one vehicle
        m.addConstrs(x.sum(v, "*") == 1 for v in idle_ev_idxs)
        m.addConstrs(x[v, c] <= mask_rnr[v][c + 1] for c in cs_idxs for v in idle_ev_idxs)
        # For each vehicle, it can be matched to at most one request
        m.addConstrs(x.sum("*", c) >= y[c] for c in cs_idxs)
        m.addConstrs(y[c] <= counts[idx] / self.request_factor for idx, c in enumerate(cs_idxs))
        m.addConstrs(x.sum(low_Q_idxs, c) >= z_low[c] for c in cs_idxs)
        m.addConstrs(x.sum(mid_Q_idxs, c) >= z_mid[c] for c in cs_idxs)
        m.addConstrs(z_low[idx] + z_mid[idx] <= self.instance.charger_count[idx] for idx in cs_idxs)
        # -> solve the model
        self._optimize(m)
        rebal_assignments = {v: r for (v, r) in x if x[(v, r)].X > 0.5}
        return rebal_assignments

    def _optimize(self, model):
        model.optimize()
        return

    def _compute_request_count(self, cs_idxs, request_coords):
        allocation_mask = geometry.distance_matrix(request_coords, self.instance.repo_coords)
        valid_mask = np.min(allocation_mask, axis=1) < self.instance.max_distance_from_request
        allocation_mask = allocation_mask[valid_mask]
        closest_index = np.argmin(allocation_mask, axis=1)
        counts, _ = np.histogram(closest_index, bins=range(len(cs_idxs) + 1))
        return counts
