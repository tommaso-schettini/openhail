from gymnasium.envs.registration import register
from .openhail_env import OpenhailEnv

register(
     id="openhail-v0",
     entry_point="openhail.core.openhail_env:OpenhailEnv",
     max_episode_steps=10000,
     )