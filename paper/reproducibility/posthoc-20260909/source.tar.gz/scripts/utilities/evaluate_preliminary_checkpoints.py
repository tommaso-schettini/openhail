#!/usr/bin/env python
"""Benchmark simulator workloads using an existing periodic-PPO checkpoint."""

from __future__ import annotations

import argparse
import csv
import math
import statistics
import time
from pathlib import Path

import numpy as np

from openhail.agents import NearestAgent, PeriodicPPOAgent, RandomAgent
from openhail.core.constants import CLOCK_EPOCH, EPOCH_TYPE
from openhail.core.openhail_env import OpenhailEnv
from openhail.core.openhail_instance import OpenhailInstance
from openhail.utils import arg_utilities

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CHECKPOINT = (
    PROJECT_ROOT
    / "out"
    / "periodic_ppo_training"
    / "periodic_ppo_variable_locations_smoke_60ep_s321"
    / "checkpoint_best.pt"
)
FLEET_CONFIGS = {
    100: ("fleet_100", "horizon_1_2k"),
    500: ("fleet_500", "horizon_1_10k"),
    1000: ("fleet_1000", "horizon_1_20k"),
    2000: ("fleet_2000", "horizon_1_40k"),
}
CHARGING_LOCATIONS = {5: 1, 10: 2, 20: 5, 40: 10}
POLICIES = ("nearest", "random", "ppo_sampled")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, default=DEFAULT_CHECKPOINT)
    parser.add_argument("--simulation", default="performance")
    parser.add_argument("--city", default="nyc")
    parser.add_argument(
        "--fleet-sizes",
        nargs="+",
        type=int,
        default=tuple(FLEET_CONFIGS),
    )
    parser.add_argument(
        "--location-counts",
        nargs="+",
        type=int,
        default=tuple(CHARGING_LOCATIONS),
    )
    parser.add_argument("--policies", nargs="+", choices=POLICIES, default=POLICIES)
    parser.add_argument("--num-episodes", type=int, default=5)
    parser.add_argument("--first-seed", type=int, default=100000)
    parser.add_argument("--first-policy-seed", type=int, default=200000)
    parser.add_argument("--decision-clock", type=float, default=900.0)
    parser.add_argument("--strict-validation", action="store_true")
    parser.add_argument("--tracking", action="store_true")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=PROJECT_ROOT / "out" / "preliminary_computational_scaling",
    )
    return parser.parse_args()


def infrastructure_name(fleet_size: int, location_count: int) -> str:
    charging_locations = CHARGING_LOCATIONS[location_count]
    charging_posts = round(0.2 * fleet_size)
    if charging_posts % charging_locations:
        raise ValueError(
            f"Cannot distribute {charging_posts} posts over "
            f"{charging_locations} charging locations."
        )
    posts_per_location = charging_posts // charging_locations
    return f"S{location_count:02d}_{charging_locations}_{posts_per_location}"


def load_config(
    args: argparse.Namespace,
    fleet_size: int,
    location_count: int,
) -> tuple[dict, str]:
    fleet, horizon = FLEET_CONFIGS[fleet_size]
    infrastructure = infrastructure_name(fleet_size, location_count)
    parser = arg_utilities.get_parser(
        simulation=args.simulation,
        evaluation="S1",
        city=args.city,
        horizon=horizon,
        fleet=fleet,
        infrastructure=infrastructure,
        agent="periodic_ppo",
    )
    config, _ = arg_utilities.load_config(parser.parse_args([]))
    simulation = config["simulation"]
    simulation["decision_clock"] = args.decision_clock
    simulation["strict_validation"] = args.strict_validation
    simulation["track_vehicles"] = args.tracking
    simulation["track_requests"] = args.tracking
    simulation["track_epochs"] = args.tracking
    return config, infrastructure


def make_agent(
    policy: str,
    instance: OpenhailInstance,
    checkpoint: Path,
    policy_seed: int,
):
    if policy == "nearest":
        return NearestAgent(instance)
    if policy == "random":
        return RandomAgent(
            instance,
            seed=policy_seed,
            periodic_repositioning=True,
        )
    return PeriodicPPOAgent(
        instance,
        training=False,
        sample_actions=True,
        checkpoint_path=str(checkpoint),
        seed=policy_seed,
    )


def run_episode(
    env: OpenhailEnv,
    policy: str,
    agent,
    seed: int,
    policy_seed: int,
) -> dict[str, int | float | str]:
    state, _ = env.reset(seed=seed)
    if isinstance(agent, RandomAgent):
        agent.seed = policy_seed
    agent.set_doy(env.request_manager.doy)
    if isinstance(agent, PeriodicPPOAgent):
        agent.begin_episode(policy_seed)

    totals = {
        "steps": 0,
        "clock_epochs": 0,
        "agent_seconds": 0.0,
        "environment_seconds": 0.0,
        "peak_charger_occupancy": 0,
        "peak_charger_queue": 0,
        "action_noop_count": 0,
        "action_reposition_count": 0,
        "action_charge_count": 0,
        "zero_capacity_charge_count": 0,
        "empty_mask_count": 0,
    }
    done = False
    wall_start = time.perf_counter()
    while not done:
        totals["clock_epochs"] += int(int(state[EPOCH_TYPE]) == CLOCK_EPOCH)
        start = time.perf_counter()
        action = agent.choose_action(state)
        after_agent = time.perf_counter()
        next_state, reward, terminated, truncated, info = env.step(action)
        after_environment = time.perf_counter()
        done = terminated or truncated
        if isinstance(agent, PeriodicPPOAgent):
            agent.observe(reward, next_state, done)
            totals["empty_mask_count"] += agent.last_empty_mask_count

        rnr_action = np.asarray(action[1], dtype=np.int32)
        repositioning = (rnr_action > 0) & (rnr_action % 2 == 1)
        charging = (rnr_action > 0) & (rnr_action % 2 == 0)
        totals["action_noop_count"] += int((rnr_action == 0).sum())
        totals["action_reposition_count"] += int(repositioning.sum())
        totals["action_charge_count"] += int(charging.sum())
        if np.any(charging):
            destinations = rnr_action[charging] // 2 - 1
            totals["zero_capacity_charge_count"] += int(
                np.count_nonzero(env.instance.charger_count[destinations] == 0)
            )

        totals["steps"] += 1
        totals["agent_seconds"] += after_agent - start
        totals["environment_seconds"] += after_environment - after_agent
        totals["peak_charger_occupancy"] = max(
            totals["peak_charger_occupancy"],
            int(np.sum(info["charger_occupancy"])),
        )
        totals["peak_charger_queue"] = max(
            totals["peak_charger_queue"],
            int(np.sum(info["charger_queue"])),
        )
        state = next_state

    return {
        "policy": policy,
        "seed": seed,
        "policy_seed": policy_seed,
        **totals,
        "wall_seconds": time.perf_counter() - wall_start,
    }


def mean_ci95(values: list[float]) -> tuple[float, float]:
    mean = statistics.fmean(values)
    if len(values) < 2:
        return mean, 0.0
    return mean, 1.96 * statistics.stdev(values) / math.sqrt(len(values))


def summarize(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    summary = []
    keys = sorted(
        {
            (row["fleet_size"], row["locations"], row["policy"])
            for row in rows
        }
    )
    for fleet_size, locations, policy in keys:
        group = [
            row
            for row in rows
            if row["fleet_size"] == fleet_size
            and row["locations"] == locations
            and row["policy"] == policy
        ]
        wall_mean, wall_ci95 = mean_ci95(
            [float(row["wall_seconds"]) for row in group]
        )
        agent_mean, agent_ci95 = mean_ci95(
            [float(row["agent_seconds"]) for row in group]
        )
        environment_mean, environment_ci95 = mean_ci95(
            [float(row["environment_seconds"]) for row in group]
        )
        steps_mean, steps_ci95 = mean_ci95(
            [float(row["steps"]) for row in group]
        )
        clocks_mean, clocks_ci95 = mean_ci95(
            [float(row["clock_epochs"]) for row in group]
        )
        throughput_mean, throughput_ci95 = mean_ci95(
            [float(row["steps"]) / float(row["wall_seconds"]) for row in group]
        )
        first = group[0]
        summary.append(
            {
                "infrastructure": first["infrastructure"],
                "fleet_size": fleet_size,
                "locations": first["locations"],
                "charging_locations": first["charging_locations"],
                "charging_posts": first["charging_posts"],
                "policy": policy,
                "episodes": len(group),
                "wall_seconds_mean": wall_mean,
                "wall_seconds_ci95": wall_ci95,
                "agent_seconds_mean": agent_mean,
                "agent_seconds_ci95": agent_ci95,
                "environment_seconds_mean": environment_mean,
                "environment_seconds_ci95": environment_ci95,
                "steps_mean": steps_mean,
                "steps_ci95": steps_ci95,
                "clock_epochs_mean": clocks_mean,
                "clock_epochs_ci95": clocks_ci95,
                "steps_per_second_mean": throughput_mean,
                "steps_per_second_ci95": throughput_ci95,
                "invalid_charge_actions": sum(
                    int(row["zero_capacity_charge_count"]) for row in group
                ),
                "empty_masks": sum(int(row["empty_mask_count"]) for row in group),
            }
        )
    return summary


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    if args.num_episodes <= 0:
        raise ValueError("--num-episodes must be positive.")
    checkpoint = args.checkpoint.resolve()
    if "ppo_sampled" in args.policies and not checkpoint.is_file():
        raise FileNotFoundError(checkpoint)
    unsupported_fleets = sorted(set(args.fleet_sizes) - set(FLEET_CONFIGS))
    if unsupported_fleets:
        raise ValueError(f"Unsupported fleet sizes: {unsupported_fleets}")
    unsupported_locations = sorted(
        set(args.location_counts) - set(CHARGING_LOCATIONS)
    )
    if unsupported_locations:
        raise ValueError(f"Unsupported location counts: {unsupported_locations}")

    rows: list[dict[str, object]] = []
    for location_count in args.location_counts:
        for fleet_size in args.fleet_sizes:
            config, infrastructure = load_config(
                args,
                fleet_size,
                location_count,
            )
            instance = OpenhailInstance(config)
            env = OpenhailEnv(instance, config["simulation"], {"render_mode": None})
            agents = {
                policy: make_agent(
                    policy,
                    instance,
                    checkpoint,
                    args.first_policy_seed,
                )
                for policy in args.policies
            }
            infrastructure_metadata = {
                "infrastructure": infrastructure,
                "fleet_size": int(instance.num_evs),
                "requests": int(config["horizon"]["num_requests"]),
                "locations": int(instance.D_repo),
                "charging_locations": int(
                    np.count_nonzero(instance.charger_count)
                ),
                "charging_posts": int(np.sum(instance.charger_count)),
            }
            for offset in range(args.num_episodes):
                seed = args.first_seed + offset
                policy_seed = args.first_policy_seed + offset
                for policy in args.policies:
                    row = {
                        **infrastructure_metadata,
                        **run_episode(
                            env,
                            policy,
                            agents[policy],
                            seed,
                            policy_seed,
                        ),
                    }
                    rows.append(row)
                    print(
                        f"N={fleet_size} L={location_count} {policy} "
                        f"seed={seed} steps={row['steps']} "
                        f"clocks={row['clock_epochs']} "
                        f"wall={row['wall_seconds']:.2f}s "
                        f"agent={row['agent_seconds']:.2f}s "
                        f"environment={row['environment_seconds']:.2f}s",
                        flush=True,
                    )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.output_dir / "episodes.csv", rows)
    summary = summarize(rows)
    write_csv(args.output_dir / "summary.csv", summary)
    print(f"Wrote preliminary computational benchmark to {args.output_dir}")


if __name__ == "__main__":
    main()
